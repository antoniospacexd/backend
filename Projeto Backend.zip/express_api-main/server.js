// importanto o express
const express = require('express');

// criando o servidor
const app = express();

// criando a rota
app.get('/', (req, res) => {
  res.send('Hello World!');
});

//criando a rota
app.get('/pessoas', (req, res) => {
  res.send('aqui é a rota de pessoas!');
});

let arrCarros = [
  {
    id: 1,
    nome: 'Fusca',
    marca: 'Volkswagen'
  }, 
  {
    id: 2,
    nome: 'Gol',
    marca: 'Volkswagen'
  }, 
  {
    id: 3,
    nome: 'Palio',
    marca: 'Fiat'
  } 
];

app.get('/carros', (req, res) => {
  console.log(arrCarros);
  res.send(arrCarros);
})

// criando a rota
app.get('/carros/:id', (req, res) => {
  const carId = req.params.id;
  const car = arrCarros.find(car => car.id === parseInt(carId));
  if (car) {
    console.log(car);
    res.send(car);
  } else {
    res.send(`Não existe carro com esse ID ${carId}`);
  }
});

/* 
  req => request|requisação => pedido de um recurso 
  res => response|resposta => resposta de um pedido
*/

app.delete('/carros/delete/:id', (req, res) => {
  const carId = req.params.id;
  arrCarros = arrCarros.filter(car => car.id !== parseInt(carId));

  res.send(`Carro ${carId} excluído com sucesso!`);

  console.log(arrCarros);

});



// iniciando o servidor
app.listen(3000);

console.log('Servidor iniciado na porta 3000');

